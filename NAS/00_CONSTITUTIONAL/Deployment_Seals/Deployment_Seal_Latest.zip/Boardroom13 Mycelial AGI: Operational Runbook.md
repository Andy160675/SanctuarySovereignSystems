# Boardroom13 Mycelial AGI: Operational Runbook

**Version:** 1.0
**Date:** 2026-02-04

This document provides the operational procedures for the Boardroom13 Mycelial AGI system, a sealed and battle-ready Truth Engine. It is intended for operators and administrators responsible for the system's deployment, maintenance, and governance.

## 1. Artifact Verification

Verification of the system's integrity is paramount. The following artifacts must be checked to ensure the system is in its sealed and validated state.

### 1.1. Core Governance Documents

These documents define the architecture and rules of the Boardroom13 system.

| Document                               | Location                                                     |
| -------------------------------------- | ------------------------------------------------------------ |
| `BOARDROOM_README.md`                  | `SOVEREIGN_SYSTEM/docs/BOARDROOM_README.md`                  |
| `Boardroom_Governance_Addendum.md`     | `SOVEREIGN_SYSTEM/docs/governance/Boardroom_Governance_Addendum.md` |
| `boardroom_system_topology.md`         | `SOVEREIGN_SYSTEM/docs/architecture/boardroom_system_topology.md` |

### 1.2. Evidence Manifest

The evidence manifest is a critical component of the Merkle Tree Audit System, providing an immutable record of all system actions.

| Document              | Location                                              |
| --------------------- | ----------------------------------------------------- |
| `manifest.jsonl`      | `SOVEREIGN_SYSTEM/sovereign-kernel/evidence/manifest.jsonl` |
| `MANIFEST_SCHEMA.md`  | `SOVEREIGN_SYSTEM/sovereign-kernel/evidence/MANIFEST_SCHEMA.md` |

**Verification Steps:**

1.  **Verify Hash Chain:** Use the `verify_decision_ledger.py` script to validate the integrity of the `decisions.jsonl` ledger.
2.  **Check Manifest Entries:** Ensure that all entries in `manifest.jsonl` conform to the schema defined in `MANIFEST_SCHEMA.md`.

### 1.3. Sovereignty Validation

The `validate_sovereignty.ps1` script is the primary tool for confirming the system's alignment with its constitutional principles.

**Execution:**

```powershell
validate_sovereignty.ps1 -All
```

**Expected Outcome:**

*   **Constitutional Stress Test:** PASS
*   **Refusal Drift Detector:** 0.00% refusal rate

## 2. Fleet Orchestration

The Sovereign System is designed for unified fleet command, with `PC-CORE-1` serving as the central orchestration point. The following scripts and tasks are used to manage the fleet.

### 2.1. Core Scripts

These scripts are located in the `scripts/fleet/` directory.

| Script                             | Description                                                                                                                              |
| ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| `orchestrate_fleet.ps1`            | The primary script for managing the fleet of nodes.                                                                                      |
| `audit_node.ps1`                   | Audits a single node and generates CSV outputs for the fleet consolidator. Supports `-NodeId` and `-EmitStandardDrop` parameters.            |
| `RUN-FleetAuditAndConsolidate.ps1` | Consolidates audit data from all nodes. Can be configured to consolidate from a network-attached storage (NAS) drop.                     |

### 2.2. VS Code Tasks

The `sovereign.code-workspace` provides the following tasks for fleet management:

| Task Name                        | Description                                                                                                                                  |
| -------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| `Audit: Node Audit (Standard Drop)` | Executes the `audit_node.ps1` script with a prompt for the `NodeId`. This task is used to generate the standard audit drop for a single node. |

### 2.3. Node Inventory

The `Governance/NODE_INVENTORY.md` file contains the inventory of all nodes in the fleet, including the `NODE-MOBILE` to `PC-CORE-1` pathway.

## 3. Data Sweep & Residual Data Inventory

Per the Project Close-Out Data Sweep and Cleanup protocol, a comprehensive sweep of all communication channels and storage locations has been performed to identify residual or unindexed data ("breadcrumbs").

### 3.1. Google Drive Inventory

The following Sovereign System-related folders have been identified in Google Drive:

| Folder Name                       | Classification | Status        |
| --------------------------------- | -------------- | ------------- |
| `SOVEREIGN_SYSTEM/`               | Primary        | **CANONICAL** |
| `Sovereign_Sanctuary_Archive/`    | Archive        | Indexed       |
| `Sovereign-Elite-Pack/`           | Documentation  | Indexed       |
| `sovereign-infra/`                | Infrastructure | Indexed       |
| `tenerife-sovereign-hub/`         | Hub            | Indexed       |
| `sovereign-elite-backups/`        | Backup         | Indexed       |
| `sovereign_elite_os_backups/`     | Backup         | Indexed       |
| `Sovereign_Elite_OS_Backups/`     | Backup         | Indexed       |
| `Sovereign/`                      | Legacy         | Review        |
| `Project folder master /`         | Legacy         | Review        |

**Recommendation:** The `Sovereign/` and `Project folder master /` folders should be reviewed for consolidation or archival into the canonical `SOVEREIGN_SYSTEM/` structure.

### 3.2. Slack Channels

The following Slack channels exist in the `sovereign-sanctuary-s` workspace:

| Channel Name                        | Purpose                        | Status  |
| ----------------------------------- | ------------------------------ | ------- |
| `#all-sovereign-sanctuary-systems`  | Announcements and updates      | Active  |
| `#first-project`                    | Project coordination           | Active  |
| `#social`                           | Team social channel            | Active  |

**Finding:** No residual project-specific data requiring cleanup was found in Slack. Channels are clean.

### 3.3. Gmail Notifications

GitHub Actions notifications for the following repositories have been identified:

| Repository                          | Notification Type              | Status         |
| ----------------------------------- | ------------------------------ | -------------- |
| `PrecisePointway/sovereign-system`  | CI/CD workflow notifications   | Active         |
| `Blade2AI/sovereign-system`         | Security scan notifications    | Active         |
| `Blade2AI/master`                   | Compliance verification        | Active         |

**Finding:** These are automated CI/CD notifications and do not constitute residual data requiring cleanup. They serve as an audit trail for system changes.

## 4. Access Control & Authorization Framework

With the system in a "SEALED" state, a strict access control policy is now in effect to ensure its integrity and prevent unauthorized modifications. Only the designated Sovereign operator is authorized to make changes.

### 4.1. Post-Deployment Authorization

All changes to the sealed system require a unique, single-use authorization code. This code must be provided to the system's command interface to unlock it for modifications. This protocol is designed to enforce the "overtly cautious, no risk" operational philosophy.

**Authorization Workflow:**

1.  **Request Change:** The operator initiates a change request through the LeanFlow interface.
2.  **Provide Authorization Code:** The system will prompt for the unique authorization code.
3.  **Execute Change:** Upon successful validation of the code, the system will permit the requested change.
4.  **Reseal System:** After the change is complete, the system will automatically re-seal, generating a new manifest and requiring a new authorization code for any subsequent changes.

### 4.2. Trust-to-Action Interface

The Trust-to-Action Interface is a core component of the governance model, enabling autonomous execution while maintaining strict control. It defines four Trust Classes for all system actions:

| Trust Class | Designation         | Description                                                                                             |
| ----------- | ------------------- | ------------------------------------------------------------------------------------------------------- |
| **T0**    | **ADVISORY**        | Manual Only. The system can provide recommendations, but all actions must be manually executed by the operator. |
| **T1**    | **CONDITIONAL**     | Auto-check, Manual trigger. The system can perform automated checks, but the final action requires operator approval. |
| **T2**    | **PRE-APPROVED**    | Automatic within bounds. The system can perform actions automatically within pre-defined, safe boundaries.       |
| **T3**    | **AUTO-EXECUTABLE** | Immediate autonomous response. The system can take immediate, autonomous action in response to critical events (e.g., security threats). |

All actions are evaluated against this framework by the Governance Kernel before execution, ensuring that the system operates within the defined trust boundaries.
