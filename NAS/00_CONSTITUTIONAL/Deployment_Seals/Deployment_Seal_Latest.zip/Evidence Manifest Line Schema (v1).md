# Evidence Manifest Line Schema (v1.1)

**Date:** 2026-02-04

Each line in `manifest.jsonl` is append-only and immutable.

Required fields:
- ts        : ISO-8601 UTC timestamp
- process   : Canonical process name
- from      : Previous state
- to        : New state
- actor     : Responsible role or individual
- artifact  : Relative path to primary evidence
- hash      : SHA-256 of artifact
- sig       : Detached signature file (must exist and verify against artifact + your/JP's key)

Example:
```json
{
  "ts": "2026-01-26T10:14:22Z",
  "process": "Property Validation",
  "from": "In Progress",
  "to": "Submitted",
  "actor": "Operations Lead",
  "artifact": "2026-01/property-validation/20260126_ConsultaPrevia_request.pdf",
  "hash": "9f1c3e7b4c...",
  "sig": "2026-01/property-validation/20260126_request_signature.asc"
}
```

Enforcement:
- Sig must be GPG detached (--armor) from artifact.
- Verifier will fail if sig doesn't match hash or isn't signed by approved keys.
